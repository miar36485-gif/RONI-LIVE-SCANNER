package com.roni.livescanner

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var apiKey: EditText
    private lateinit var interval: Spinner
    private val prefs by lazy { getSharedPreferences("roni", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(28, 36, 28, 24)
        }
        layout.addView(TextView(this).apply {
            text = "RONI LIVE SCANNER PRO"; textSize = 24f; gravity = Gravity.CENTER
        })
        layout.addView(TextView(this).apply {
            text = "ExpertOption screen scanner • Real Market only"; textSize = 14f
        })
        apiKey = EditText(this).apply {
            hint = "Twelve Data API Key (নিজের key দিন)"
            setText(prefs.getString("api", ""))
        }
        layout.addView(apiKey)
        interval = Spinner(this)
        interval.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("5 seconds","10 seconds","15 seconds","30 seconds","1 minute","2 minutes","5 minutes"))
        interval.setSelection(prefs.getInt("interval", 0))
        layout.addView(TextView(this).apply { text = "Scan interval" })
        layout.addView(interval)
        layout.addView(Button(this).apply {
            text = "১. Overlay permission দিন"
            setOnClickListener {
                prefs.edit().putString("api", apiKey.text.toString().trim())
                    .putInt("interval", interval.selectedItemPosition).apply()
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Overlay permission already enabled", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(Button(this).apply {
            text = "২. Screen Scan চালু করুন"
            setOnClickListener {
                prefs.edit().putString("api", apiKey.text.toString().trim())
                    .putInt("interval", interval.selectedItemPosition).apply()
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "আগে Overlay permission দিন", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), 2001)
            }
        })
        layout.addView(TextView(this).apply {
            text = "ব্যবহার: ExpertOption খুলে Android-এর Screen Capture অনুমতি দিন। স্ক্যানার স্ক্রিনের লেখা থেকে মার্কেট শনাক্ত করার চেষ্টা করবে।"
            textSize = 13f
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2001 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScannerService::class.java).apply {
                putExtra("resultCode", resultCode); putExtra("data", data)
            }
            startForegroundService(i)
            Toast.makeText(this, "Scanner চালু হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }
}
