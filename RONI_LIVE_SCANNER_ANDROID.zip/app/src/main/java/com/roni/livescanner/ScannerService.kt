package com.roni.livescanner

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import org.json.JSONObject

class ScannerService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: TextView? = null
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var lastMarket = ""
    private var busy = false
    private var lastScanAt = 0L

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        showOverlay()
        startCapture()
        return START_STICKY
    }

    private fun createNotification() {
        val channel = "roni_scanner"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(channel, "RONI Scanner", NotificationManager.IMPORTANCE_LOW))
        }
        val n = Notification.Builder(this, channel)
            .setContentTitle("RONI LIVE SCANNER PRO")
            .setContentText("Screen scanning active — tap Stop in overlay")
            .setSmallIcon(android.R.drawable.ic_menu_search).build()
        startForeground(7, n)
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = TextView(this).apply {
            text = "RONI SCANNER\nScreen reading..."
            textSize = 13f; setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xE6222222.toInt()); setPadding(18, 12, 18, 12)
            setOnClickListener { stopSelf() }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.END; p.x = 16; p.y = 180
        wm.addView(overlay, p)
    }

    private fun startCapture() {
        val metrics = resources.displayMetrics
        val w = metrics.widthPixels; val h = metrics.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (!busy) {
                busy = true
                processImage(img)
            } else img.close()
        }, handler)
        virtualDisplay = projection?.createVirtualDisplay("RoniCapture", w, h, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
    }

    private fun processImage(image: Image) {
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val bitmap = android.graphics.Bitmap.createBitmap(
                image.width + rowPadding / pixelStride, image.height, android.graphics.Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(buffer)
            val cropped = android.graphics.Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
            image.close(); bitmap.recycle()
            val input = InputImage.fromBitmap(cropped, 0)
            recognizer.process(input).addOnSuccessListener { result ->
                val text = result.text.uppercase()
                val market = detectMarket(text)
                if (market.isNotBlank()) {
                    val changed = market != lastMarket
                    lastMarket = market
                    val seconds = listOf(5,10,15,30,60,120,300)
                        .getOrElse(getSharedPreferences("roni", Context.MODE_PRIVATE).getInt("interval", 0)) { 5 }
                    val now = android.os.SystemClock.elapsedRealtime()
                    if (changed || now - lastScanAt >= seconds * 1000L) {
                        lastScanAt = now
                        scanMarket(market)
                    }
                } else update("RONI SCANNER\nMarket not detected\nExpertOption-এ asset name স্পষ্ট রাখুন")
                cropped.recycle()
            }.addOnFailureListener {
                cropped.recycle(); update("RONI SCANNER\nScreen OCR failed")
            }.addOnCompleteListener { busy = false }
        } catch (e: Exception) {
            try { image.close() } catch (_: Exception) {}
            busy = false
        }
    }

    private fun detectMarket(t: String): String {
        val pairs = listOf("EUR/USD","GBP/USD","USD/JPY","AUD/USD","USD/CAD","USD/CHF",
            "NZD/USD","EUR/GBP","EUR/JPY","GBP/JPY","XAU/USD","XAG/USD","BTC/USD","ETH/USD")
        return pairs.firstOrNull { t.contains(it) || t.contains(it.replace("/", "")) } ?: ""
    }

    private fun scanMarket(symbol: String) {
        val prefs = getSharedPreferences("roni", Context.MODE_PRIVATE)
        val key = prefs.getString("api", "") ?: ""
        if (key.isBlank()) {
            update("RONI SCANNER\n$symbol\nAPI key missing\nTwelve Data key দিন")
            return
        }
        executor.execute {
            try {
                val url = URL("https://api.twelvedata.com/time_series?symbol=${symbol.replace("/", "%2F")}&interval=1min&outputsize=40&apikey=$key")
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                val body = c.inputStream.bufferedReader().use { it.readText() }
                c.disconnect()
                val j = JSONObject(body)
                if (!j.has("values")) { update("$symbol\nData unavailable\n${j.optString("message","Provider error")}"); return@execute }
                val arr = j.getJSONArray("values")
                if (arr.length() < 25) { update("$symbol\nNot enough candle data"); return@execute }
                val closes = (0 until arr.length()).map { arr.getJSONObject(it).getDouble("close") }.reversed()
                val fast = closes.takeLast(9).average()
                val slow = closes.takeLast(21).average()
                val rsi = calculateRsi(closes)
                val signal = when {
                    fast > slow && rsi in 52.0..68.0 -> "CALL"
                    fast < slow && rsi in 32.0..48.0 -> "PUT"
                    else -> "WAIT"
                }
                update("$symbol  •  1 MIN\n$signal\nRSI: ${"%.1f".format(rsi)}\nEMA9/21: ${if (fast>slow) "UP" else "DOWN"}\nTap to stop")
            } catch (e: Exception) {
                update("$symbol\nConnection / API error\n${e.message ?: ""}")
            }
        }
    }

    private fun calculateRsi(c: List<Double>): Double {
        val diffs = c.zipWithNext { a,b -> b-a }.takeLast(14)
        val gains = diffs.filter { it > 0 }.sum() / 14.0
        val losses = -diffs.filter { it < 0 }.sum() / 14.0
        if (losses == 0.0) return 100.0
        val rs = gains/losses
        return 100.0 - 100.0/(1.0+rs)
    }

    private fun update(s: String) { handler.post { overlay?.text = s } }

    override fun onDestroy() {
        try { virtualDisplay?.release(); reader?.close(); projection?.stop(); overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        executor.shutdownNow()
        super.onDestroy()
    }
}
