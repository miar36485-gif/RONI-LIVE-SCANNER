RONI LIVE SCANNER PRO — Android Source Project
=============================================

এটি একটি Android Studio source project; APK ফাইল নয়।

ফিচার:
- Android floating overlay panel
- Android MediaProjection user consent দিয়ে screen capture
- ML Kit OCR দিয়ে স্ক্রিনে থাকা কয়েকটি পরিচিত asset pair শনাক্তের চেষ্টা
- Twelve Data API থেকে 1-minute candles নিয়ে EMA/RSI ভিত্তিক সাধারণ CALL/PUT/WAIT indication
- Overlay-এ ট্যাপ করলে scanner বন্ধ

সীমাবদ্ধতা / জরুরি সতর্কতা:
1) এটি ExpertOption-এর private feed বা account-এ লগইন করে না।
2) OCR সবসময় asset চিনতে পারবে এমন নিশ্চয়তা নেই; স্ক্রিনে pair name দৃশ্যমান থাকতে হবে।
3) Twelve Data-র quote ExpertOption-এর quote-এর সঙ্গে আলাদা হতে পারে। OTC নয়; এই কোডে OTC যোগ করা হয়নি।
4) 5-second refresh নির্বাচন UI-তে আছে, কিন্তু এই প্রথম source build-এ scan request-গুলো OCR frame এলে চালু হয়; নির্ভরযোগ্য 5-second scheduler পরের সংস্করণে যোগ করতে হবে। Provider rate limits প্রযোজ্য।
5) CALL/PUT কোনো নিশ্চিত ভবিষ্যদ্বাণী নয়; আর্থিক সিদ্ধান্তের আগে নিজে যাচাই করুন।
6) Android 14/15-এ MediaProjection foreground service ও overlay অনুমতি OS prompt-এ দিতে হবে।

Build:
- Android Studio-তে project folder খুলুন
- Gradle sync শেষ হতে দিন
- Build > Build Bundle(s) / APK(s) > Build APK(s)
- APK সাধারণত app/build/outputs/apk/debug/app-debug.apk এ তৈরি হবে

API Key:
- Twelve Data থেকে নিজের API key নিন
- অ্যাপে API key field-এ লিখুন
- API key কাউকে পাঠাবেন না

Phone:
- APK install করে অ্যাপ খুলুন
- Overlay permission দিন
- API key লিখুন
- Screen Scan চালু করুন এবং Android screen-capture prompt-এ Start now দিন
- এরপর ExpertOption খুলুন; overlay-এ tap করলে scanner বন্ধ হবে

এই source code-টি starter build। ফোনে APK build করতে Android Studio-সহ কম্পিউটার অথবা cloud Android build workflow লাগতে পারে।
